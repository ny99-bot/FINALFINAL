import React from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Info } from 'lucide-react';
import { USE_MOCK_DATA } from '../api/backendAPI';

export default function MockDataBanner() {
  if (!USE_MOCK_DATA) return null;

  return (
    <Alert className="bg-blue-50 border-blue-200 mb-6">
      <Info className="h-4 w-4 text-blue-600" />
      <AlertDescription className="text-blue-900 ml-2">
        <strong>Demo Mode:</strong> Backend not connected — using placeholder data. 
        To connect your AI backend, set <code className="bg-blue-100 px-1 rounded">VITE_API_BASE_URL</code> in your environment.
      </AlertDescription>
    </Alert>
  );
}