/**
 * Pack-It unified backend adapter with offline mocks.
 * - Uses VITE_API_BASE_URL if set (e.g., https://yonewbackend.onrender.com)
 * - Falls back to mock data when empty (Demo Mode).
 */
const API_BASE_URL = (import.meta?.env?.VITE_API_BASE_URL || '').trim();
const USE_MOCK_DATA = !API_BASE_URL;

async function postJson(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
  if (!res.ok) throw new Error(`API ${res.status} ${url}`);
  return res.json();
}

const KEYWORD_WEIGHTS = [
  { rx: /jean|denim/i, kg: 0.7 },
  { rx: /hoodie|sweatshirt/i, kg: 0.8 },
  { rx: /sweater|jumper/i, kg: 0.6 },
  { rx: /jacket|coat|parka/i, kg: 1.0 },
  { rx: /blazer/i, kg: 0.9 },
  { rx: /pant|trouser/i, kg: 0.6 },
  { rx: /short/i, kg: 0.35 },
  { rx: /t-?shirt|tee/i, kg: 0.2 },
  { rx: /shirt/i, kg: 0.25 },
  { rx: /dress/i, kg: 0.35 },
  { rx: /skirt/i, kg: 0.25 },
  { rx: /sock/i, kg: 0.05 },
  { rx: /underwear|brief|boxer|panty/i, kg: 0.05 },
  { rx: /shoe|sneaker|boot/i, kg: 0.9 },
  { rx: /laptop/i, kg: 1.3 },
  { rx: /tablet|ipad/i, kg: 0.5 },
  { rx: /phone|iphone|android/i, kg: 0.2 },
  { rx: /camera/i, kg: 0.6 },
  { rx: /charger|cable|adapter/i, kg: 0.1 },
  { rx: /toiletr|tooth|shampoo|soap|razor|cosmetic/i, kg: 0.4 },
];

const CATEGORY_DEFAULTS = {
  Clothing: 0.25,
  Toiletries: 0.4,
  Electronics: 0.3,
  Shoes: 0.9,
  Other: 0.3,
};

function estimateItemKg(item) {
  const name = String(item?.name || '').trim();
  for (const rule of KEYWORD_WEIGHTS) {
    if (rule.rx.test(name)) return rule.kg;
  }
  const cat = String(item?.category || '').trim();
  if (cat && CATEGORY_DEFAULTS[cat] != null) return CATEGORY_DEFAULTS[cat];
  return 0.25;
}

function mockWeightEstimates({ items = [] }) {
  const list = items.map((it) => {
    const per = estimateItemKg(it);
    const kg = +(per * (it.qty || 1)).toFixed(2);
    return { name: it.name, aiWeight: kg };
  });
  const totalKg = list.reduce((s, x) => s + x.aiWeight, 0);
  return {
    totalG: Math.round(totalKg * 1000),
    totalKg: +totalKg.toFixed(2),
    items: list,
  };
}

function mockSuggestions({ destination, travelClass, purpose, items = [] }) {
  const names = items.map(i => (i.name || '').toLowerCase());
  const pushIfMissing = (arr, n) => { if (!names.includes(n.toLowerCase())) arr.push(n); };
  const out = [];
  pushIfMissing(out, "Socks (2 pairs)");
  pushIfMissing(out, "Underwear (2)");
  pushIfMissing(out, "Toothbrush");
  if (/snow|cold|alaska|iceland|canada|winter/i.test(destination || '')) {
    pushIfMissing(out, "Thermal layer");
    pushIfMissing(out, "Gloves");
    pushIfMissing(out, "Beanie");
  } else {
    pushIfMissing(out, "Sunscreen");
    pushIfMissing(out, "Hat / Cap");
  }
  if (/business|first/i.test(travelClass || '') || /business|conference/i.test(purpose || '')) {
    pushIfMissing(out, "Blazer");
    pushIfMissing(out, "Dress shoes");
  }
  return out;
}

function mockOptimization({ items = [], limitKg = 23 }) {
  const total = items.reduce((s, it) => s + (it.weight || 0), 0);
  const rec = [];
  let running = total;
  const sorted = [...items].sort((a,b) => (b.weight||0) - (a.weight||0));
  for (const it of sorted) {
    if (running <= limitKg) break;
    rec.push({ action: "remove", name: it.name, kg: it.weight || 0 });
    running -= (it.weight || 0);
  }
  return {
    totalBefore: +total.toFixed(2),
    totalAfter: +running.toFixed(2),
    limitKg,
    recommendations: rec,
  };
}

function mockPackingSteps({ items = [], luggageType = 'suitcase' }) {
  return {
    luggageType,
    steps: [
      { title: "Lay Out & Audit", body: "Lay all items on a bed. Remove duplicates and heavy maybes." },
      { title: "Use Packing Cubes", body: "Group by category (tops, bottoms, underwear, tech)." },
      { title: "Heaviest by Wheels", body: "Place jeans/hoodies/shoes near the wheels for balance." },
      { title: "Fill Gaps", body: "Socks/underwear fill corners; protect fragile items." },
      { title: "Personal Item", body: "Keep meds, documents, chargers, and valuables accessible." },
    ]
  };
}

export const backendAPI = {
  getSuggestions: async (payload) => {
    if (USE_MOCK_DATA) {
      await new Promise(r => setTimeout(r, 200));
      return { suggestions: mockSuggestions(payload) };
    }
    try {
      return await postJson(`${API_BASE_URL}/ai/suggest`, payload);
    } catch {
      return await postJson(`${API_BASE_URL}/gemini/suggest`, payload);
    }
  },
  getWeightEstimates: async (payload) => {
    if (USE_MOCK_DATA) {
      await new Promise(r => setTimeout(r, 200));
      return mockWeightEstimates(payload);
    }
    try {
      return await postJson(`${API_BASE_URL}/ai/weights`, payload);
    } catch {
      return await postJson(`${API_BASE_URL}/gemini/weights`, payload);
    }
  },
  getOptimization: async (payload) => {
    if (USE_MOCK_DATA) {
      await new Promise(r => setTimeout(r, 150));
      return mockOptimization(payload);
    }
    try {
      return await postJson(`${API_BASE_URL}/ai/optimize`, payload);
    } catch {
      return await postJson(`${API_BASE_URL}/gemini/optimize`, payload);
    }
  },
  getPackingSteps: async (payload) => {
    if (USE_MOCK_DATA) {
      await new Promise(r => setTimeout(r, 150));
      return mockPackingSteps(payload);
    }
    try {
      return await postJson(`${API_BASE_URL}/ai/steps`, payload);
    } catch {
      return await postJson(`${API_BASE_URL}/gemini/steps`, payload);
    }
  },
};

export { USE_MOCK_DATA, API_BASE_URL };
