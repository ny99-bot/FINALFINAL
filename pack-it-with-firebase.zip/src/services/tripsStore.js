
import { db } from "@/lib/firebase";
import {
  collection, doc, addDoc, getDocs, getDoc, setDoc, query, orderBy, serverTimestamp
} from "firebase/firestore";
import { getDeviceUid } from "@/lib/userId";

function tripsCol(uid) {
  return collection(db, "users", uid, "trips");
}

export async function listTrips() {
  const uid = getDeviceUid();
  const q = query(tripsCol(uid), orderBy("createdAt", "desc"));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function getTrip(id) {
  const uid = getDeviceUid();
  const ref = doc(db, "users", uid, "trips", id);
  const snap = await getDoc(ref);
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

export async function saveTrip(trip) {
  const uid = getDeviceUid();
  if (trip.id) {
    const ref = doc(db, "users", uid, "trips", trip.id);
    await setDoc(ref, { ...trip, updatedAt: serverTimestamp() }, { merge: true });
    return trip.id;
  }
  const res = await addDoc(tripsCol(uid), {
    ...trip,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return res.id;
}
